package controllers;

import play.*;
import play.data.validation.Required;
import play.mvc.*;
import play.mvc.results.Result;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.plaf.metal.MetalBorders.Flush3DBorder;
import javax.xml.bind.DatatypeConverter;

import org.joda.time.LocalDate;
import org.w3c.dom.css.ViewCSS;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;

import models.*;

public class Application extends Controller {

	private static String userid = null;
	private static Connection connection = getDBConnection();
	//Server mail sender details
	private static final String from_gmailId = "?@gmail.com"; //provide gmailId in ?
	private static final String from_password = "?"; //provide gmail password in Base64 form
	public static Connection getDBConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres");
		}
		catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return connection;
	}
    public static void login() {
    	render();
    }
    public static void authentication(String username,String password) throws UnsupportedEncodingException, InterruptedException {

    	
    	try {
    		System.out.println("Connected to PostgreSQL database : authenticataion!");
			if(password!=null) 
			{
				byte[] pwd = password.getBytes("UTF-8");
		    	String encoded = DatatypeConverter.printBase64Binary(pwd);
				PreparedStatement statement1 = connection.prepareStatement("SELECT * FROM user_info where userid = ? and passwordhash = ?");
				statement1.setString(1,username);
				statement1.setString(2,encoded);
				ResultSet resultSet1 = statement1.executeQuery();
				if(!resultSet1.next())
				{
					PreparedStatement statement2 = connection.prepareStatement("SELECT * FROM user_info where userid = ?");
					statement2.setString(1,username);
					ResultSet resultSet2 = statement2.executeQuery();
					if(!resultSet2.next())
						signup();
					else
					{
						flash.error("Invalid Password");
						login();
					}
				}
				else 
				{
					userid = username;
					dashboard();
				}
			}
		}  
    	catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
    }
    public static void dashboard() {
    	render();
    }
    public static void signup() {
    	render();
    }
    public static void register(String username,String name,String email,String dob,String password) throws ParseException, UnsupportedEncodingException {
    	
    	try {

    		System.out.println("Connected to PostgreSQL database : register!");
    		byte[] pwd = password.getBytes("UTF-8");
    		String encoded = DatatypeConverter.printBase64Binary(pwd);
			PreparedStatement statement = connection.prepareStatement("INSERT INTO user_info VALUES(?,?,?,?,?)");
			statement.setString(1,username);
			statement.setString(2,encoded);
			statement.setString(3,name);
			statement.setString(4,dob);
			statement.setString(5,email);
			try {
				int row = statement.executeUpdate();
			}
			catch(Exception e) {
				flash.error("username already exists");
				signup();
			}
			render(username);
		}  catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
    }
    @SuppressWarnings("deprecation")
	public static void addContact(String contactid) {

    	try {

    		System.out.println("Connected to PostgreSQL database : addContact!" + contactid);
    		PreparedStatement statement1 = connection.prepareStatement("SELECT * FROM user_info WHERE userid = ?");
    		statement1.setString(1,contactid);
    		ResultSet rs1 = statement1.executeQuery();
    		if(rs1.next())
    		{
    			PreparedStatement statement2 = connection.prepareStatement("INSERT INTO user_contacts VALUES(?,?)");
    			statement2.setString(1,userid);
    			statement2.setString(2,contactid);
    				try {
    					statement2.executeUpdate();
    				}
    				catch(SQLException e) {
    					flash.error("contact is already added");
    					dashboard();
    				}
    				try {
    					String dob = rs1.getString("dateofbirth");
	    				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    				Date DOB = format.parse(dob);
	    				Date currdate = new Date();
	    				DOB.setYear(currdate.getYear());
	    				long diff = DOB.getTime() - currdate.getTime();
	    				long diffHours = diff/(60*60*1000);
	    				PreparedStatement statement3 = connection.prepareStatement("SELECT * FROM user_info WHERE userid = ?");
	    	    		statement3.setString(1,userid);
	    	    		ResultSet rs3 = statement3.executeQuery();
	    	    		long parameter = -1;
	    	    		if(rs3.next())
	    	    			parameter = (long)rs3.getInt("birthday_parameter");
	    	    		if(diffHours <= parameter)
	    	    			sendEmail(rs3.getString("email"),contactid,parameter);
    				}
    				catch(Exception e) {
    					flash.error("Email service failed");
    			}
    		}
    		else
    			flash.error("contactid doesn't exist");
    		dashboard();
		}  
    	catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
    }
    public static void setParameter(int parameter) {

    	try {
    		System.out.println("Connected to PostgreSQL database : setparameter!" + parameter);
    		PreparedStatement statement = connection.prepareStatement("UPDATE user_info SET birthday_parameter = ? WHERE userid = ?");
    		statement.setInt(1,parameter);
    		statement.setString(2,userid);
    		statement.executeUpdate();
    		flash.success("Birthday parameter has been set");
    		dashboard();
		}  
    	catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
    }

    public static void sendEmail(String RECIPIENT,String contactid,long parameter) throws UnsupportedEncodingException {
    	String from = from_gmailId;
        String pass = from_password;
        byte[] decoded = DatatypeConverter.parseBase64Binary(pass);
        pass = new String(decoded,"UTF-8");
        String[] to = { RECIPIENT }; // list of recipient email addresses
        String subject = "Upcoming birthday : "+contactid;
        String body = contactid +"'s birthday is in "+parameter+" hours";
    	Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", pass);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);

        try {
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];

            // To get the array of addresses
            for( int i = 0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }

            for( int i = 0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }

            message.setSubject(subject);
            message.setText(body);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, from, pass);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            flash.success("New mail received");
            dashboard();
        }
        catch (AddressException ae) {
            ae.printStackTrace();
        }
        catch (MessagingException me) {
            me.printStackTrace();
        }
    }
}