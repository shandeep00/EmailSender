package jobs;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.xml.bind.DatatypeConverter;

import play.jobs.*;

@On("0 0/1 * 1/1 * ? *") //0 0 0/1 1/1 * ? *
public class Batchjob extends Job{
	private final String from_gmailId = "?@gmail.com"; //provide gmailId in ?
	private final String from_password = "?"; //provide gmail password in Base64 form
	public void doJob() {
		System.out.println("BATCH JOB STARTED");
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {

    		System.out.println("Connected to PostgreSQL database : run!");
    		
    		PreparedStatement statement1 = connection.prepareStatement("SELECT * FROM user_info");
    		ResultSet rs1 = statement1.executeQuery();
    		while(rs1.next())
    		{
    			String uid = rs1.getString("userid");
    			long parameter = rs1.getInt("birthday_parameter");
    			String email = rs1.getString("email");
    			PreparedStatement statement2 = connection.prepareStatement("SELECT * FROM user_contacts WHERE userid = ?");
    			statement2.setString(1,uid);
    			ResultSet rs2 = statement2.executeQuery();
    			while(rs2.next())
    			{
    				String contactId = rs2.getString("contactid");
    				PreparedStatement statement3 = connection.prepareStatement("SELECT * FROM user_info WHERE userid = ?");
    				statement3.setString(1,contactId);
    				ResultSet rs3 = statement3.executeQuery();
    				if(rs3.next())
    				{
    					String dob = rs3.getString("dateofbirth");
        				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        				Date DOB = format.parse(dob);
        				Date currentDate = new Date();
        				DOB.setYear(currentDate.getYear());
	    				long diff = DOB.getTime() - currentDate.getTime();
	    				long diffHours = diff/(60*60*1000);
        				if(diffHours <= parameter)
        					sendEmail(email, contactId,parameter);
    				}
    			}
    		}
    		
		}  catch (Exception e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
	}
	public static void sendEmail(String RECIPIENT,String contactid,long parameter) throws UnsupportedEncodingException {
    	String from = from_gmailId; //from email name
        String pass = from_password; //from emai password in Base64 encryption
        byte[] decoded = DatatypeConverter.parseBase64Binary(pass);
        pass = new String(decoded,"UTF-8");
        String[] to = { RECIPIENT }; // list of recipient email addresses
        String subject = "Upcoming birthday : "+contactid;
        String body = contactid +"'s birthday is in "+parameter+" hours";
    	Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", pass);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);

        try {
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];

            // To get the array of addresses
            for( int i = 0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }

            for( int i = 0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }

            message.setSubject(subject);
            message.setText(body);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, from, pass);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        }
        catch (AddressException ae) {
            ae.printStackTrace();
        }
        catch (MessagingException me) {
            me.printStackTrace();
        }
    }
}
